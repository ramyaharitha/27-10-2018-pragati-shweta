package com.cg.hms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import antlr.collections.List;

import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;
import com.cg.hms.dao.IHotelDao;

@Service
public class HotelService implements IHotelService{

	@Override
	public boolean isValidUser(String adminname, String adminpass) {
		if(adminname=="admin"&&adminpass=="admin")
		{
			
		}
		return false;
	}
	@Autowired
	private IHotelDao hdao;

	@Override
	public int addUserDetails(UserBean u) {
		int b=hdao.addUserDetails(u);
		
		return b;
	}

	@Override
	public boolean login(String userName, String password, UserBean userbean) {
		
		return  hdao.login(userName,password,userbean);
	}
	
	@Override
	public int addHotelServ(HotelBean hotelbean) {
		System.out.println("inside service");
		int bookhotel=hdao.addHotelServ(hotelbean);
		
		return bookhotel;
	}

	@Override
	public int addRoomServ(RoomBean roombean) {
		System.out.println("inside service");
		int bookroom=hdao.addRoomServ(roombean);
		
		return bookroom;
	}

	@Override
	public ArrayList<HotelBean> getAllHotels() {
		
		return hdao.getAllHotels();
	}

	@Override
	public int deleteHotelById(int deletehotelid) {
		System.out.println("inside service deletehotelid");
		return hdao.deleteHotelById(deletehotelid);
	}

	@Override
	public int deleteroomById(int deleteroomid) {
		System.out.println("inside service deleteroomid");
		return hdao.deleteroomById(deleteroomid);
	}

	@Override
	public ArrayList<HotelBean> searchHotelById(int id) {
		
		return hdao.searchHotelById(id);
	}

	@Override
	public void updateHotelDetails(HotelBean hotelBean) 
	{
		hdao.updateHotelDetails(hotelBean);

	}


	

}
