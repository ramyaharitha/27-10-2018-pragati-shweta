package com.cg.hms.controller;

import java.net.Authenticator.RequestorType;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import antlr.collections.List;

import com.cg.hms.bean.AdminBean;
import com.cg.hms.bean.EmployeeBean;
import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;
import com.cg.hms.service.IHotelService;




@Controller
public class HotelController {

	/******************************************************First Page********************************************/
	@RequestMapping(value="home")
	public String getHome(Model m)
	{
		return "home";
	}


	@RequestMapping(value="user",method = RequestMethod.POST)								
	public String user(Model m,@ModelAttribute("userBean") UserBean userbean )
	{
		return "userlogin";
	}

	
	@RequestMapping(value="emp",method = RequestMethod.POST)
	public String emp(Model m)
	{
		return "employeelogin";
	}

	
	@RequestMapping(value="employeelogin")
	public String getEmpLoginPage(Model m)
	{
		return "employeelogin";
	}

	
	@RequestMapping(value="login")
	public String getadminloginPage(Model m)
	{
		return "login";
	}
	
	
	@RequestMapping("reg")
	public String getregistration(Model m)
	{
		m.addAttribute("regObj", new  UserBean());
		return "UserRegistration";
	}

	
	
	 /*****************************************Admin Functionality******************************************************/	
	 


	@RequestMapping(value="admin",method = RequestMethod.POST)
	public String main(Model m)
	{
		return "adminlogin";
	}
	@RequestMapping(value="hotelmanagement")                                        //Hotel Management
	public String performHotelManagement(Model m)
	{
		return "adminhm";

	}
	@RequestMapping(value="roommanagement")                                        //Room Management
	public String performRoomManagement(Model m)
	{
		return "adminrm";

	}


	@RequestMapping(value="report")                                                 //Generate Reports
	public String generateReport(Model m)
	{
		
		return "adminreport";

	}

	/****************************Hotel Management***************************************/

	@RequestMapping(value="addhotel")                                                           // Add Hotel
	public String addHotel(Model m,@ModelAttribute("hotelObj") HotelBean hotel )
	{
		return "addhotel";

	}
	@RequestMapping(value="deletehotel")                                                          // Delete Hotel
	public String deleteHotel(Model m,@ModelAttribute("deletehotelObj") HotelBean hotel)
	{
		return "deletehotel";

	}
	@RequestMapping(value="updatehotel",method=RequestMethod.POST)                                                          //Update Hotel
	public String searchHotelById(Model m,@ModelAttribute("updatehotelObj")HotelBean hotelbean)
	{
		HotelBean Obj = new HotelBean();
		m.addAttribute("updatehotelObj", Obj);
		return "updatehotel";

	}
	@RequestMapping(value="updateDetails",method=RequestMethod.POST)                                                          //Update Hotel
	public String update(Model m,@ModelAttribute("updatehotelObj") HotelBean hotelBean,@RequestParam("id") int id)
	{
		
		hotelBean.setHotelid(id);
		m.addAttribute("hotelBean",hotelBean);
		hserv.updateHotelDetails(hotelBean);
		String msg="Update Successfully";
		
		return "updatesuccess";

	}
	
	
/************************************************************Hotel Management Methods**********************************************************/
	
	/*****************************************************************Add Hotel***************************************************************/
	
	@RequestMapping(value="performaddhotel",method=RequestMethod.POST)
	public  String storehotel(Model m,@ModelAttribute("hotelObj") HotelBean hotelbean){
		String target=null;
		int  hotelId=hserv.addHotelServ(hotelbean);
		System.out.println(hotelId);
		m.addAttribute("id", hotelId);
		
		if( hotelId > 0){
			System.out.println("in if");
			m.addAttribute("msg","stored successfully");
			m.addAttribute("id", hotelId);
			target="success";
		}
		else{
			target="performaddhotel";
		}
		return target;
	}

	/*****************************************************************Delete Hotel***************************************************************/
	
	@RequestMapping(value="deletehotelbyid",method=RequestMethod.POST)
	public  String deletehotel(Model m,@ModelAttribute("deletehotelObj") HotelBean hotelbean)
	{
		String target=null;
		int deletehotelid = hotelbean.getHotelid();
		int result;
		result=hserv.deleteHotelById(deletehotelid);
		if(result>0)
		{
			m.addAttribute("msg","Rows deleted successfully");
			m.addAttribute("deleteid", deletehotelid);
			target="deletesuccess";

		}
		else
		{
			target="home";
		}
		return target;
	}
	
	/*****************************************************************Update Hotel***************************************************************/
	
	 
	@RequestMapping(value="updatehotelbyid",method=RequestMethod.POST)
	public ModelAndView SelectHotel(Model m ,@ModelAttribute("updatehotelObj") HotelBean hotelbean)
	{
		int id = hotelbean.getHotelid();
		System.out.println(id);
		ModelAndView mv=new ModelAndView();
		ArrayList<HotelBean> hotellist=hserv.searchHotelById(id);
		mv.setViewName("updatehotelbyid");
		System.out.println(hotelbean);
		mv.addObject("data", hotellist);
		return mv;
	}
	
	
	
	
	
	
	
	
	
	
	/************************************************************ROOM MANAGEMENT METHODS**********************************************************/
	
	/*****************************************************************ADD ROOMS********************************************************************/

	@RequestMapping(value="performaddroom",method=RequestMethod.POST)
	public  String storeroom(Model m,@ModelAttribute("roomObj") RoomBean roombean){
		String target=null;
		int  roomId=hserv.addRoomServ(roombean);
		if( roomId>0){
			System.out.println("in if");
			m.addAttribute("msg","stored successfully");
			m.addAttribute("id", roomId);
			target="success";
		}
		else{
			target="performaddroom";
		}
		return target;
	}
	
	/******************************************************************DELETE ROOMS****************************************************************/
	
	@RequestMapping(value="deleteroombyid",method=RequestMethod.POST)
	public  String deleteroom(Model m,@ModelAttribute("deleteroomObj") RoomBean roombean)
	{
		String target=null;
		int deleteroomid = roombean.getRoomid();
		int result;
		result=hserv.deleteroomById(deleteroomid);
		if(result>0)
		{
			m.addAttribute("msg","Rows deleted successfully");
			m.addAttribute("deleteid", deleteroomid);
			target="deletesuccess";
		}
		else
		{
			target="home";
		}
		return target;
	}
	

	/****************************Room Management***************************************/

	@RequestMapping(value="addroom")															//Add Room
	public String addRoom(Model m,@ModelAttribute("roomObj") RoomBean roombean)
	{
		return "addroom";

	}
	@RequestMapping(value="deleteroom")															//Delete Room
	public String deleteRoom(Model m,@ModelAttribute("deleteroomObj") RoomBean roombean)
	{
		return "deleteroom";

	}
	@RequestMapping(value="updateroom")														//Update Room
	public String updateRoom(Model m)
	{
		return "updateroom";

	}
/***********************************************************************************************************************************************************************************************************************/


	@Autowired
	private IHotelService hserv;

	
	/************************************************************User Registration*******************************************************************/	
	@RequestMapping(value="register",method=RequestMethod.POST)
	
	public  String storeRechargeInfo(Model m,@ModelAttribute("regObj") UserBean u){
		String target=null;

		int  userId=hserv.addUserDetails(u);
		if( userId>0){
			System.out.println("in if");
			m.addAttribute("msg","stored successfully");
			m.addAttribute("id", userId);
			target="success";
		}
		else{
			target="UserRegistration";
		}
		return target;
	}
	
	/************************************************************User Login*******************************************************************/

	@RequestMapping(value="Userform",method = RequestMethod.POST)
	public String submit3(Model model, @ModelAttribute("userBean") UserBean userbean) {
		String target=null;
		model.addAttribute(userbean);
		model.addAttribute("user",userbean.getUserName());
		model.addAttribute("pass",userbean.getPassword());
		boolean val=hserv.login(userbean.getUserName(),userbean.getPassword(),userbean);
		if(val)
		{
			target="usermainscreen";
		}
		else
		{
			target="userlogin";
			model.addAttribute("status","Login Successfull");
		}
		return target;
				
		
	}
	
	/*********************************************************Emplpoyee Login*****************************************************************/

	@RequestMapping(value="empForm",method = RequestMethod.POST)
	public String submit1(Model model, @ModelAttribute("empBean") EmployeeBean empBean)
	{
		if (empBean != null && empBean.getUserName() != null & empBean.getPassword() != null)
		{
			if (empBean.getUserName().equals("emp") && empBean.getPassword().equals("emp")) 
			{
				model.addAttribute("msg", empBean.getUserName());
				return "empmainscreen";
			} else {
				model.addAttribute("error", "Invalid Details");
				return "employeelogin";
			}
		} else {
			model.addAttribute("error", "Please enter Details");
			return "employeelogin";
		}
	}	


	/******************************************************Admin Register********************************************************************/

	@RequestMapping(value="adminForm",method = RequestMethod.POST)
	public String submit(Model model, @ModelAttribute("loginBean") AdminBean loginBean) {
		if (loginBean != null && loginBean.getUserName() != null & loginBean.getPassword() != null) 
		{
			if (loginBean.getUserName().equals("admin") && loginBean.getPassword().equals("admin")) 
			{
				model.addAttribute("msg", loginBean.getUserName());
				return "adminmainscreen";
			}
			else 
			{
				model.addAttribute("error", "Invalid Details");
				return "adminlogin";
			}
		} 
		else 
		{
			model.addAttribute("error", "Please enter Details");
			return "adminlogin";
		}
	}
	////////////////////////Search Hotel/////////////////////////////
	@RequestMapping(value="searchhotel",method = RequestMethod.POST)
	public String search()
	{
		return null;

	}
	
	
	
	
	/*******************************************************GENERATE VARIOUS REPORTS**************************************************************/
	
	/********************************************************  View All Hotels ********************************************************************/
	
	@RequestMapping(value="viewallhotels",method=RequestMethod.POST)
	public ModelAndView viewAll(){
		ModelAndView mv=new ModelAndView();
		ArrayList<HotelBean> hotellist=hserv.getAllHotels();
		mv.setViewName("viewallhotels");
		mv.addObject("data", hotellist);
		return mv;
	}
	

	/*****************************************************View Booking Of Specific Hotel **********************************************/
	

	


	 /**************************************************View Booking Of Specified Date**************************************************/



	
	/*public  String deleteroom(Model m,@ModelAttribute("deleteroomObj") RoomBean roombean)
	{
		String target=null;
		int deleteroomid = roombean.getRoomid();
		int result;
		result=hserv.deleteroomById(deleteroomid);
		if(result>0)
		{
			m.addAttribute("msg","Rows deleted successfully");
			m.addAttribute("deleteid", deleteroomid);
			target="deletesuccess";
		}
		else
		{
			target="home";
		}
		return target;
		public List<Brand> getBrand(@RequestParam(value="name") String name) {
    return brandService.getSome(name);
}
		
		
		
	*/
	
	
	
	
	
	
	/*************************************************  View Guest list Of Specific Hotel *********************************************/


	
	
	
	
	
	
	
	
	
}



