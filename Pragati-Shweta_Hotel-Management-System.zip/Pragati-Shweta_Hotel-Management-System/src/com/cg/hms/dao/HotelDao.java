package com.cg.hms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;
@Repository
@Transactional
public class HotelDao implements IHotelDao
{
	@PersistenceContext
	private EntityManager em;
/***************Registration****************/
	@Override
	public int addUserDetails(UserBean u) {
		em.persist(u);
		System.out.println(u.getUserId());
		return u.getUserId();
	
	}
	/****************************Login******************************/
	@Override
	public boolean login(String userName, String password, UserBean userbean) 
	{
		boolean status=true;
		Query qry=em.createNamedQuery("loginquery");
		qry.setParameter("user",userbean.getUserName());
		qry.setParameter("pass",userbean.getPassword());
		List result =qry.getResultList();
	    System.out.println(result);
	    if(result.isEmpty())
	    {
	    	status=false;
	    }
		return status;
	}

	@Override
	public int addHotelServ(HotelBean hotelbean) {
		System.out.println("inside dao");
		em.persist(hotelbean);
		System.out.println(hotelbean.getHotelid());
		return hotelbean.getHotelid();
	}

	@Override
	public int addRoomServ(RoomBean roombean) {
		System.out.println("inside dao");
		em.persist(roombean);
		
		
		return roombean.getRoomid();
	}

	@Override
	public ArrayList<HotelBean> getAllHotels() {
		Query qry=em.createNamedQuery("getAllHotels");
		return (ArrayList<HotelBean>) qry.getResultList();
	}

	
	@Override
	public int deleteHotelById(int deletehotelid) {
		Query deleteQuery=em.createQuery("delete HotelBean where hotelid =:delhid");
		deleteQuery.setParameter("delhid",deletehotelid);
		int result = deleteQuery.executeUpdate();
		return result;
	}
	@Override
	public int deleteroomById(int deleteroomid) {
	
		Query deleteQuery=em.createQuery("delete HotelBean where hotelid =:delrid");
		deleteQuery.setParameter("delrid",deleteroomid);
		int result = deleteQuery.executeUpdate();
		return result;
	}
	@Override
	public ArrayList<HotelBean> searchHotelById(int id) {
		Query query=em.createQuery("select r from HotelBean r where r.hotelid=:id");
		query.setParameter("id", id);

		return (ArrayList<HotelBean>) query.getResultList();
	}
	@Override
	public void updateHotelDetails(HotelBean hotelBean) {
		
		String desc=hotelBean.getDescription();
		int amount=hotelBean.getAvgratepernight();
		int id=hotelBean.getHotelid();
		//int id=hotelBean.getHotelid();
		
		Query updateHotel = em.createQuery("update HotelBean h set h.description=:descr, h.avgratepernight=:rate where h.hotelid=:idd ");
		updateHotel.setParameter("descr", desc);
		updateHotel.setParameter("rate", amount);
		updateHotel.setParameter("idd", id);
		updateHotel.executeUpdate();
	}
	

}
