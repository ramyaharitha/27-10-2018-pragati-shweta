package com.cg.hms.dao;

import java.util.ArrayList;

import antlr.collections.List;

import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;

public interface IHotelDao 
{
	public int addUserDetails(UserBean u);

	public int addHotelServ(HotelBean hotelbean);

	public int addRoomServ(RoomBean roombean);

	public ArrayList<HotelBean> getAllHotels();



	public int deleteHotelById(int deletehotelid);

	
	public boolean login(String userName, String password, UserBean userbean);

	public int deleteroomById(int deleteroomid);
	//public int searchHotelById(int gethotelid);

	

	public ArrayList<HotelBean> searchHotelById(int id);
	
	public void updateHotelDetails(HotelBean hotelBean);

}
